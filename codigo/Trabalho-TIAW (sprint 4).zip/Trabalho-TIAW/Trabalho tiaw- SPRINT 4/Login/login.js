window.onload=function(){
   
  let btn = document.querySelector('.fa-eye')
  
  btn.addEventListener('click', ()=>{
    let inputSenha = document.querySelector('#senha')
    
    if(inputSenha.getAttribute('type') == 'password'){
      inputSenha.setAttribute('type', 'text')
    } else {
      inputSenha.setAttribute('type', 'password')
    }
  })
  
  bt2.onclick = function entrar(){
      let usuario = document.querySelector('#usuario')
      let userLabel = document.querySelector('#userLabel')
      
      let senha = document.querySelector('#senha')
      let senhaLabel = document.querySelector('#senhaLabel')
      
      let msgError = document.querySelector('#msgError')
      let listaUser = []
      
      /* let userValid = {
        nome: '',
        user: '',
        senha: ''
      } */
      
      listaUser = JSON.parse(localStorage.getItem('listaUser'))
      
      /* listaUser.forEach((item) => {
        if(usuario.value == item.userCad && senha.value == item.senhaCad){
           
          userValid = {
             nome: item.nomeCad,
             user: item.userCad,
             senha: item.senhaCad
           }
          
        }
      }) */
        for (let index = 0; index < listaUser.length; index++) {
          if(usuario.value == listaUser[index].userCad && senha.value == listaUser[index].senhaCad){
            window.location.href = '../teladelugares/index.html'
            
            let mathRandom = Math.random().toString(16).substr(2)
            let token = mathRandom + mathRandom
            
            localStorage.setItem('token', token)
            localStorage.setItem('userLogado', JSON.stringify(userValid))
            
            
          }
          
          else {
            
            
            userLabel.setAttribute('style', 'color: red')
            usuario.setAttribute('style', 'border-color: red')
            senhaLabel.setAttribute('style', 'color: red')
            senha.setAttribute('style', 'border-color: red')
            msgError.setAttribute('style', 'display: block')
            msgError.innerHTML = 'Usuário ou senha incorretos'
            usuario.focus()
          }
          
        }
        
      }
        function cadastrar(){
          if(validNome && validUsuario && validSenha && validConfirmSenha){
            let listaUser = JSON.parse(localStorage.getItem('listaUser') || '[]')
            
            listaUser.push(
              {
          nomeCad: nome.value,
          userCad: usuario.value,
          senhaCad: senha.value
        }
        )
        
        localStorage.setItem('listaUser', JSON.stringify(listaUser))
        
       
        msgSuccess.setAttribute('style', 'display: block')
        msgSuccess.innerHTML = '<strong>Cadastrando usuário...</strong>'
        msgError.setAttribute('style', 'display: none')
        msgError.innerHTML = ''
        
        setTimeout(()=>{
            window.location.href = 'https://cdpn.io/thicode/debug/ZELzYxV/dXAqBaRyvwJk'
        }, 3000)
      
        
      } else {
        msgError.setAttribute('style', 'display: block')
        msgError.innerHTML = '<strong>Preencha todos os campos corretamente antes de cadastrar</strong>'
        msgSuccess.innerHTML = ''
        msgSuccess.setAttribute('style', 'display: none')
      }
    }
    
    
  }