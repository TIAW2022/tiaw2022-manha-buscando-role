function entrada(){
var email = document.querySelector("#user");
var senha = document.querySelector("#password")

var Email = localStorage.getItem("Email");
var Senha = localStorage.getItem("Senha");

const parsedEmail = Email.slice(2, Email.length - 2);
  const parsedSenha = Senha.slice(2, Senha.length - 2);

  console.log(parsedEmail)

  if(email.value===parsedEmail && senha.value===parsedSenha){

    alert("Login concluido")

  }

  else{

    alert("Login incompleto")
  }

}